package com.example.dailyquizapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun MyScreen(modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(16.dp)) {
        Text(
            text = "我的",
            style = MaterialTheme.typography.headlineSmall
        )
        Spacer(modifier = Modifier.height(16.dp))
        // 占位内容，可根据需求替换
        Text("用户名称: [用户名]", style = MaterialTheme.typography.bodyLarge)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { /* 跳转到设置页面或执行其他逻辑 */ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("设置")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { /* 退出登录或其他逻辑 */ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("退出登录")
        }
    }
}